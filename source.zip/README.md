Visit https://docs.scaffoldhub.io for docs/instructions.
Version: 2.7.8