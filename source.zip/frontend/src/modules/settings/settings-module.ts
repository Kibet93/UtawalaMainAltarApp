import routes from '@/modules/settings/settings-routes';
import store from '@/modules/settings/settings-store';

export default {
  routes,
  store,
};
