import routes from '@/modules/dashboard/dashboard-routes';

export default {
  routes,
};
