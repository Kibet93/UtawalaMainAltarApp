import routes from '@/modules/tenant/tenant-routes';
import store from '@/modules/tenant/tenant-store';

export default {
  routes,
  store,
};
