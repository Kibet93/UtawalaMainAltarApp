import { UserModel } from '@/modules/user/user-model';

const { fields } = UserModel;

export default [fields.email, fields.rolesRequired];
