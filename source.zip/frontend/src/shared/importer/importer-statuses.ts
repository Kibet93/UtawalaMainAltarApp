export default {
  PENDING: 'PENDING',
  IMPORTED: 'IMPORTED',
  ERROR: 'ERROR',
};
