import * as yup from 'yup';
import moment from 'moment';
import { i18n } from '@/i18n';
import GenericField from '@/shared/fields/generic-field';

export default class DateField extends GenericField {
  required: boolean;
  placeholder: string;
  hint: string;

  constructor(
    name,
    label,
    config: {
      placeholder?;
      hint?;
      required?;
    } = {},
  ) {
    super(name, label);

    this.required = config.required;
    this.placeholder = config.placeholder;
    this.hint = config.hint;
  }

  forPresenter(value) {
    return value;
  }

  forFilterPreview(value) {
    return value
      ? moment(value).format('YYYY-MM-DD')
      : null;
  }

  forImportViewTable(value) {
    return value
      ? moment(value).format('YYYY-MM-DD')
      : null;
  }

  forFilterCast() {
    return yup
      .mixed()
      .nullable(true)
      .label(this.label)
      .transform((value) =>
        value ? moment(value).format('YYYY-MM-DD') : null,
      );
  }

  forFormRules() {
    const output: Array<any> = [];

    if (this.required) {
      output.push({
        required: true,
        message: i18n('validation.mixed.required').replace(
          '${path}',
          this.label,
        ),
      });
    }

    return output;
  }

  forFormInitialValue(value) {
    return value ? moment(value, 'YYYY-MM-DD') : null;
  }

  forFormCast() {
    let yupChain = yup
      .mixed()
      .nullable(true)
      .label(this.label)
      .transform((value) =>
        value ? moment(value).format('YYYY-MM-DD') : null,
      );

    return yupChain;
  }

  forExport() {
    return yup.mixed().label(this.label);
  }

  forImport() {
    let yupChain = yup
      .mixed()
      .nullable(true)
      .label(this.label)
      .test(
        'is-date',
        i18n('validation.mixed.default'),
        (value) => {
          if (!value) {
            return true;
          }

          return moment(value, 'YYYY-MM-DD').isValid();
        },
      )
      .transform((value) =>
        value ? moment(value).format('YYYY-MM-DD') : null,
      );

    if (this.required) {
      yupChain = yupChain.required();
    }

    return yupChain;
  }
}
