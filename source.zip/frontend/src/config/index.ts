const config = require(`./${
  process.env.VUE_APP_ENVIRONMENT
}`).default;

export default config;
