module.exports = {
  lintOnSave: false,
  productionSourceMap: false,
  devServer: {
    allowedHosts: ['.localhost'],
  },
};
