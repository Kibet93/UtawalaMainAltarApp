export interface IServiceOptions {
  language: string;
  currentUser: any;
  currentTenant: any;
  database: any;
}
